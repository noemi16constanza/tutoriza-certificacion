import os
import sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from app import create_app, db
from app.models import User, Tutor

app = create_app()

with app.app_context():
    db.create_all()
    # crear dos usuarios con emails únicos para no colisionar con DB existente
    import uuid
    a_email = f"a_{uuid.uuid4().hex}@example.com"
    b_email = f"b_{uuid.uuid4().hex}@example.com"
    a = User(nombre='UsuarioA', apellido='Uno', email=a_email, password_hash='x')
    b = User(nombre='TutorB', apellido='Dos', email=b_email, password_hash='x')
    db.session.add_all([a,b])
    db.session.commit()

    # marcar b como tutor
    t = Tutor(user_id=b.id)
    db.session.add(t)
    db.session.commit()

    # usar test_client para simular login de a
    client = app.test_client()
    with client.session_transaction() as sess:
        sess['_user_id'] = str(a.id)

    # obtener la página de nuevo
    resp = client.get('/nuevo')
    html = resp.get_data(as_text=True)
    print('GET /nuevo status:', resp.status_code)
    # comprobar que el tutor B aparece en el select
    appears = 'TutorB' in html and 'b@example.com' not in html  # email not shown in select, check name
    print('TutorB aparece en /nuevo?', appears)
    if not appears:
        # imprimir una porción del HTML para diagnóstico
        start = html.find('<select')
        end = html.find('</select>', start)
        print('Select html snippet:\n', html[start:end+9])

    # ahora simular que A marca a si mismo como tutor
    resp2 = client.post('/tutores/mark_me')
    print('POST /tutores/mark_me ->', resp2.status_code)
    # comprobar que marcarme retorna a listar_tutores (302) o similar
    # comprobar que existe tutor para a
    exists_a = Tutor.query.filter_by(user_id=a.id).first() is not None
    print('Usuario A ahora es tutor?', exists_a)

    # NOTE: not removing created users to avoid FK issues in existing DB
    print('Test finished (no cleanup to avoid FK collisions)')

from app import create_app
import webbrowser
import threading

app = create_app()

# Añadir tutores para las asesorías (disponibles en app.config['TUTORES'])
app.config.setdefault('TUTORES', [])
app.config['TUTORES'].extend([
    {'nombre': 'Rayen'},
    {'nombre': 'Nicol'},
])

# Mostrar mensaje con tutores y URL antes de arrancar
print("Tutores disponibles:", [t.get('nombre') for t in app.config.get('TUTORES', [])])
print("Iniciando la aplicación en http://127.0.0.1:8050 ...")

# Función que abre el navegador en la URL de la app
def _abrir_navegador():
    try:
        webbrowser.open_new("http://127.0.0.1:8050")
    except Exception:
        pass

if __name__ == "__main__":
    # Iniciar un timer corto para abrir el navegador tras arrancar el servidor
    threading.Timer(1.0, _abrir_navegador).start()
    # Ejecutar en localhost en el puerto 8050 sin reloader para evitar procesos duplicados
    app.run(host='127.0.0.1', port=8050, debug=True, use_reloader=False)

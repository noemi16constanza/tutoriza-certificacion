from app import create_app, db, bcrypt
from app.models import User

app = create_app()

with app.app_context():
    users = [
        {'nombre': 'Juan', 'apellido': 'Perez', 'email': 'juan@example.com', 'password': 'secret1'},
        {'nombre': 'María', 'apellido': 'Gomez', 'email': 'maria@example.com', 'password': 'secret2'},
    ]

    created = 0
    for u in users:
        if not User.query.filter_by(email=u['email']).first():
            pw = bcrypt.generate_password_hash(u['password']).decode('utf-8')
            user = User(nombre=u['nombre'], apellido=u['apellido'], email=u['email'], password_hash=pw)
            db.session.add(user)
            created += 1
    if created:
        db.session.commit()
    print(f"Usuarios creados: {created}")
    all_users = User.query.all()
    for user in all_users:
        print(user.id, user.nombre, user.apellido, user.email)

-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema tutoriza_db
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `tutoriza_db` ;

-- -----------------------------------------------------
-- Schema tutoriza_db
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `tutoriza_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ;
USE `tutoriza_db` ;

-- -----------------------------------------------------
-- Table `tutoriza_db`.`users`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tutoriza_db`.`users` ;

CREATE TABLE IF NOT EXISTS `tutoriza_db`.`users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(50) NOT NULL,
  `apellido` VARCHAR(50) NOT NULL,
  `email` VARCHAR(120) NOT NULL,
  `password_hash` VARCHAR(128) NOT NULL,
  `created_at` DATETIME NULL DEFAULT NULL,
  `is_admin` TINYINT(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE INDEX `email` (`email` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table `tutoriza_db`.`asesorias`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tutoriza_db`.`asesorias` ;

CREATE TABLE IF NOT EXISTS `tutoriza_db`.`asesorias` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `tema` VARCHAR(120) NOT NULL,
  `fecha` DATE NOT NULL,
  `duracion` INT NOT NULL,
  `notas` VARCHAR(250) NULL DEFAULT NULL,
  `creador_id` INT NOT NULL,
  `tutor_id` INT NULL DEFAULT NULL,
  `created_at` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `creador_id` (`creador_id` ASC) VISIBLE,
  INDEX `tutor_id` (`tutor_id` ASC) VISIBLE,
  CONSTRAINT `asesorias_ibfk_1`
    FOREIGN KEY (`creador_id`)
    REFERENCES `tutoriza_db`.`users` (`id`),
  CONSTRAINT `asesorias_ibfk_2`
    FOREIGN KEY (`tutor_id`)
    REFERENCES `tutoriza_db`.`users` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

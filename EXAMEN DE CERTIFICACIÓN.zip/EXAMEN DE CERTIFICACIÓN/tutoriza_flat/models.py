from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy
from app import db, login_manager

# Nota: `db` y `login_manager` se importan desde app.py

class User(db.Model, UserMixin):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(50), nullable=False)
    apellido = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)

class Asesoria(db.Model):
    __tablename__ = 'asesorias'
    id = db.Column(db.Integer, primary_key=True)
    tema = db.Column(db.String(100), nullable=False)
    fecha = db.Column(db.Date, nullable=False)
    duracion = db.Column(db.Integer, nullable=False)
    notas = db.Column(db.String(250))
    solicitante_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    tutor_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    solicitante = db.relationship('User', foreign_keys=[solicitante_id])
    tutor = db.relationship('User', foreign_keys=[tutor_id])


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

from flask import render_template, redirect, url_for, flash, request, abort
from flask_login import login_user, logout_user, login_required, current_user
from datetime import date
from . import db, bcrypt
from .models import User, Asesoria
from .models import Tutor
from .forms import RegisterForm, LoginForm, AsesoriaForm, TutorForm
from werkzeug.urls import url_parse
from flask import current_app as app


# Rutas:


@app.route('/')
@login_required
def index():
    # Dashboard: mostrar solo asesorías futuras (no mostrar pasadas)
    hoy = date.today()
    asesorias = Asesoria.query.filter(Asesoria.fecha >= hoy).order_by(Asesoria.fecha).all()
    return render_template('index.html', asesorias=asesorias)





def _require_admin():
    if not current_user.is_admin:
        abort(403)


@app.route('/tutores/nuevo', methods=['GET', 'POST'])
@login_required
def agregar_tutor():
    _require_admin()
    form = TutorForm()
    if form.validate_on_submit():
        pw_hash = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(
            nombre=form.nombre.data.strip(),
            apellido=form.apellido.data.strip(),
            email=form.email.data.strip(),
            password_hash=pw_hash
        )
        db.session.add(user)
        db.session.commit()
        flash('Tutor creado correctamente.', 'success')
        return redirect(url_for('listar_tutores'))
    return render_template('agregar_tutor.html', form=form)


@app.route('/tutores')
@login_required
def listar_tutores():
    _require_admin()
    # mostrar usuarios que han sido marcados como tutores
    tutors = Tutor.query.join(User, Tutor.user_id == User.id).order_by(User.nombre).all()
    tutor_users = [t.user for t in tutors]
    # también pasar la lista de todos los usuarios para permitir marcar/desmarcar
    all_users = User.query.order_by(User.nombre).all()
    tutor_ids = {t.user_id for t in tutors}
    return render_template('tutores_list.html', tutors=tutor_users, all_users=all_users, tutor_ids=tutor_ids)


@app.route('/tutores/mark/<int:user_id>', methods=['POST'])
@login_required
def marcar_como_tutor(user_id):
    _require_admin()
    user = User.query.get_or_404(user_id)
    # si ya es tutor, no hacer nada
    if Tutor.query.filter_by(user_id=user.id).first():
        flash('Usuario ya es tutor.', 'info')
        return redirect(url_for('listar_tutores'))
    t = Tutor(user_id=user.id)
    db.session.add(t)
    db.session.commit()
    flash('Usuario marcado como tutor.', 'success')
    return redirect(url_for('listar_tutores'))


@app.route('/tutores/unmark/<int:user_id>', methods=['POST'])
@login_required
def desmarcar_como_tutor(user_id):
    _require_admin()
    user = User.query.get_or_404(user_id)
    t = Tutor.query.filter_by(user_id=user.id).first()
    if not t:
        flash('Usuario no es tutor.', 'info')
        return redirect(url_for('listar_tutores'))
    db.session.delete(t)
    db.session.commit()
    flash('Usuario removido como tutor.', 'success')
    return redirect(url_for('listar_tutores'))


@app.route('/tutores/mark_me', methods=['POST'])
@login_required
def marcar_me_como_tutor():
    # permitir que cualquier usuario se marque a sí mismo como tutor
    existing = Tutor.query.filter_by(user_id=current_user.id).first()
    if existing:
        flash('Ya eres tutor.', 'info')
        return redirect(url_for('listar_tutores'))
    t = Tutor(user_id=current_user.id)
    db.session.add(t)
    db.session.commit()
    flash('Ahora eres tutor.', 'success')
    return redirect(url_for('listar_tutores'))


@app.route('/tutores/unmark_me', methods=['POST'])
@login_required
def desmarcar_me_como_tutor():
    # permitir que cualquier usuario se quite el rol de tutor sobre sí mismo
    t = Tutor.query.filter_by(user_id=current_user.id).first()
    if not t:
        flash('No eres tutor.', 'info')
        return redirect(url_for('listar_tutores'))
    db.session.delete(t)
    db.session.commit()
    flash('Ya no eres tutor.', 'success')
    return redirect(url_for('listar_tutores'))


@app.route('/tutores/editar/<int:user_id>', methods=['GET', 'POST'])
@login_required
def editar_tutor(user_id):
    _require_admin()
    user = User.query.get_or_404(user_id)
    form = TutorForm(obj=user)
    if form.validate_on_submit():
        user.nombre = form.nombre.data.strip()
        user.apellido = form.apellido.data.strip()
        user.email = form.email.data.strip()
        if form.password.data:
            user.password_hash = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        db.session.commit()
        flash('Tutor actualizado.', 'success')
        return redirect(url_for('listar_tutores'))
    return render_template('editar_tutor.html', form=form, user=user)


@app.route('/tutores/borrar/<int:user_id>', methods=['POST'])
@login_required
def borrar_tutor(user_id):
    _require_admin()
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash('No puedes eliminar tu propia cuenta.', 'danger')
        return redirect(url_for('listar_tutores'))
    db.session.delete(user)
    db.session.commit()
    flash('Tutor eliminado.', 'success')
    return redirect(url_for('listar_tutores'))
# Gestión de tutores removida del proyecto.


@app.route('/health')
def health():
    return 'ok', 200


@app.route('/register', methods=['GET', 'POST'])
def auth_register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = RegisterForm()
    if form.validate_on_submit():
        pw_hash = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(
            nombre=form.nombre.data.strip(),
            apellido=form.apellido.data.strip(),
            email=form.email.data.strip(),
            password_hash=pw_hash
        )
        db.session.add(user)
        db.session.commit()
        flash('Registro exitoso. Puedes iniciar sesión.', 'success')
        return redirect(url_for('auth_login'))
    return render_template('register.html', form=form)


@app.route('/login', methods=['GET', 'POST'])
def auth_login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data.strip()).first()
        if user and bcrypt.check_password_hash(user.password_hash, form.password.data):
            login_user(user)
            flash('Inicio de sesión correcto.', 'success')
            next_page = request.args.get('next')
            if not next_page or url_parse(next_page).netloc != '':
                next_page = url_for('index')
            return redirect(next_page)
        else:
            flash('Credenciales inválidas.', 'danger')
    return render_template('login.html', form=form)


@app.route('/logout')
@login_required
def auth_logout():
    logout_user()
    flash('Has cerrado sesión.', 'info')
    return redirect(url_for('index'))


@app.route('/nuevo', methods=['GET', 'POST'])
@login_required
def nuevo():
    form = AsesoriaForm()
    # Poblar la lista de tutores disponibles
    # Excluir al solicitante (no puede ser su propio tutor)
    tutors = Tutor.query.join(User, Tutor.user_id == User.id).filter(User.id != current_user.id).order_by(User.nombre).all()
    # tutors is list of Tutor objects; extract user
    tutor_users = [t.user for t in tutors]
    choices = [(-1, '--- Sin tutor ---')] + [(u.id, f"{u.nombre} {u.apellido}") for u in tutor_users]
    form.tutor.choices = choices
    if form.validate_on_submit():
        if form.fecha.data < date.today():
            flash('No puedes crear una asesoría con fecha en el pasado.', 'danger')
            return render_template('nuevo.html', form=form)
        ases = Asesoria(
            tema=form.tema.data.strip(),
            fecha=form.fecha.data,
            duracion=form.duracion.data,
            notas=form.notas.data.strip(),
            creador_id=current_user.id
        )
        # guardar tutor seleccionado (None si -1)
        tutor_sel = form.tutor.data
        if tutor_sel is not None and int(tutor_sel) != -1:
            ases.tutor_id = int(tutor_sel)
        db.session.add(ases)
        db.session.commit()
        flash('Asesoría creada.', 'success')
        return redirect(url_for('index'))
    return render_template('nuevo.html', form=form)


@app.route('/ver/<int:ases_id>', methods=['GET', 'POST'])
def ver(ases_id):
    ases = Asesoria.query.get_or_404(ases_id)
    # siempre pasar la lista de usuarios marcados como tutores (excluyendo al creador)
    tutors = Tutor.query.join(User, Tutor.user_id == User.id).filter(User.id != ases.creador_id).order_by(User.nombre).all()
    tutors = [t.user for t in tutors]
    return render_template('ver.html', ases=ases, tutors=tutors)


@app.route('/ver/<int:ases_id>/cambiar_tutor', methods=['POST'])
@login_required
def cambiar_tutor(ases_id):
    ases = Asesoria.query.get_or_404(ases_id)
    # Solo el creador puede cambiar el tutor
    if ases.creador_id != current_user.id:
        abort(403)
    tutor_sel = request.form.get('tutor')
    try:
        tutor_id = int(tutor_sel) if tutor_sel is not None else -1
    except (ValueError, TypeError):
        tutor_id = -1
    if tutor_id == -1:
        ases.tutor_id = None
    else:
        tutor = User.query.get(tutor_id)
        if not tutor or tutor.id == ases.creador_id:
            flash('Tutor inválido.', 'danger')
            return redirect(url_for('ver', ases_id=ases.id))
        ases.tutor_id = tutor.id
    db.session.commit()
    flash('Tutor actualizado.', 'success')
    return redirect(url_for('ver', ases_id=ases.id))


@app.route('/editar/<int:ases_id>', methods=['GET', 'POST'])
@login_required
def editar(ases_id):
    ases = Asesoria.query.get_or_404(ases_id)
    if ases.creador_id != current_user.id:
        abort(403)
    form = AsesoriaForm(obj=ases)
    # Poblar opciones de tutor (excluir al creador como tutor) usando solo usuarios marcados como tutores
    tutors = Tutor.query.join(User, Tutor.user_id == User.id).filter(User.id != ases.creador_id).order_by(User.nombre).all()
    tutor_users = [t.user for t in tutors]
    choices = [(-1, '--- Sin tutor ---')] + [(u.id, f"{u.nombre} {u.apellido}") for u in tutor_users]
    form.tutor.choices = choices
    # Si GET, poner el valor actual
    if request.method == 'GET':
        form.tutor.data = ases.tutor_id or -1

    if form.validate_on_submit():
        if form.fecha.data < date.today():
            flash('La fecha no puede estar en el pasado.', 'danger')
            return render_template('editar.html', form=form, ases=ases)
        ases.tema = form.tema.data.strip()
        ases.fecha = form.fecha.data
        ases.duracion = form.duracion.data
        ases.notas = form.notas.data.strip()
        # actualizar tutor segun seleccion
        tutor_sel = form.tutor.data
        ases.tutor_id = None if (tutor_sel is None or int(tutor_sel) == -1) else int(tutor_sel)
        db.session.commit()
        flash('Asesoría actualizada.', 'success')
        return redirect(url_for('index'))
    return render_template('editar.html', form=form, ases=ases)


@app.route('/borrar/<int:ases_id>', methods=['POST'])
@login_required
def borrar(ases_id):
    ases = Asesoria.query.get_or_404(ases_id)
    if ases.creador_id != current_user.id:
        abort(403)
    db.session.delete(ases)
    db.session.commit()
    flash('Asesoría eliminada.', 'success')
    return redirect(url_for('index'))

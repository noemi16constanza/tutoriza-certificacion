from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, IntegerField, TextAreaField, DateField, SelectField
from wtforms.validators import DataRequired, Email, EqualTo, Length, NumberRange, ValidationError, Optional
from .models import User
from . import db
from datetime import date as _date


def only_letters(form, field):
    if not field.data.isalpha():
        raise ValidationError("Sólo se permiten letras.")


class RegisterForm(FlaskForm):
    nombre = StringField('Nombre', validators=[DataRequired(), Length(min=2), only_letters])
    apellido = StringField('Apellido', validators=[DataRequired(), Length(min=2), only_letters])
    email = StringField('E-mail', validators=[DataRequired(), Email()])
    password = PasswordField('Contraseña', validators=[DataRequired(), Length(min=6)])
    confirm = PasswordField('Confirmar Contraseña', validators=[DataRequired(), EqualTo('password', message='Las contraseñas deben coincidir.')])
    submit = SubmitField('Registrar')

    def validate_email(self, email):
        if User.query.filter_by(email=email.data).first():
            raise ValidationError("El email ya está registrado.")


class LoginForm(FlaskForm):
    email = StringField('E-mail', validators=[DataRequired(), Email()])
    password = PasswordField('Contraseña', validators=[DataRequired()])
    submit = SubmitField('Iniciar Sesión')


class AsesoriaForm(FlaskForm):
    tema = StringField('Tema', validators=[DataRequired(), Length(min=1)])
    fecha = DateField('Fecha', validators=[DataRequired()], format='%Y-%m-%d')
    duracion = IntegerField('Duración (horas)', validators=[DataRequired(), NumberRange(min=1, max=8)])
    notas = TextAreaField('Notas', validators=[Length(max=50)])
    # hacer opcional: si no hay tutor se guarda None
    tutor = SelectField('Tutor', coerce=int, validators=[Optional()])
    submit = SubmitField('Guardar')
    # Validación adicional: fecha no puede ser en el pasado
    def validate_fecha(self, fecha):
        if fecha.data and fecha.data < _date.today():
            raise ValidationError('La fecha no puede estar en el pasado.')

    def validate_tutor(self, tutor):
        # tutor comes as int (or -1 for none). If provided, ensure user exists.
        try:
            t = int(tutor.data)
        except Exception:
            return
        if t is not None and t != -1:
            if not User.query.get(t):
                raise ValidationError('Tutor seleccionado no existe.')


class TutorForm(FlaskForm):
    nombre = StringField('Nombre', validators=[DataRequired(), Length(min=2)])
    apellido = StringField('Apellido', validators=[DataRequired(), Length(min=2)])
    email = StringField('E-mail', validators=[DataRequired(), Email()])
    password = PasswordField('Contraseña', validators=[DataRequired(), Length(min=6)])
    submit = SubmitField('Crear Tutor')

    def validate_email(self, email):
        if User.query.filter_by(email=email.data).first():
            raise ValidationError('El email ya está registrado.')



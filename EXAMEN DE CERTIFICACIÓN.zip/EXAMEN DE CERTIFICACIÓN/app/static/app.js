document.addEventListener('DOMContentLoaded', function(){
  // Reveal elements with class .reveal
  document.querySelectorAll('.reveal').forEach(function(el, i){
    setTimeout(function(){ el.classList.add('animate-in') }, 80 * i);
  });

  // Auto-dismiss flash messages
  const flashes = document.querySelectorAll('.flashes .flash');
  flashes.forEach(function(f, i){
    setTimeout(function(){ f.classList.add('hide') }, 4200 + (i*300));
  });

  // Small interaction: floating label helper (optional)
  // Small interaction: floating label helper (optional)
  // limit to inputs inside .fancy-form to avoid global side-effects
  document.querySelectorAll('.fancy-form .input, .fancy-form textarea, .fancy-form select').forEach(function(inp){
    inp.addEventListener('focus', function(){ inp.classList.add('focused') });
    inp.addEventListener('blur', function(){ if(!inp.value) inp.classList.remove('focused') });
  });
  // mark already-filled inputs (autofill) so labels float
  document.querySelectorAll('.fancy-form .input, .fancy-form textarea, .fancy-form select').forEach(function(inp){
    if(inp.value && inp.value.trim() !== ''){
      inp.classList.add('focused');
      var lab = inp.parentNode ? inp.parentNode.querySelector('.label') : null;
      if(lab) lab.classList.add('focused');
    }
  });
  // run again after window load and a short timeout (covers browser autofill that fires after DOMContentLoaded)
  function markFilled(){
    document.querySelectorAll('.fancy-form .input, .fancy-form textarea, .fancy-form select').forEach(function(inp){
      if(inp.value && inp.value.trim() !== ''){
        inp.classList.add('focused');
        var lab = inp.parentNode ? inp.parentNode.querySelector('.label') : null;
        if(lab) lab.classList.add('focused');
      }
    });
  }
  window.addEventListener('load', function(){
    markFilled();
    setTimeout(markFilled, 300);
    setTimeout(markFilled, 900);
    // extra late retry for stubborn autofill implementations
    setTimeout(markFilled, 1500);
  });
  
  // Page transition: intercept internal link clicks and form submits to animate out
  const revealRoot = document.querySelector('.reveal') || document.querySelector('main') || document.body;

  function playExitAndThen(fn){
    // add class to play exit animation
    revealRoot.classList.remove('animate-in');
    revealRoot.classList.add('animate-out');
    document.documentElement.classList.add('page-transitioning');
    // wait duration similar to CSS animation then call fn
    setTimeout(function(){ fn(); }, 320);
  }

  // intercept internal links
  document.addEventListener('click', function(ev){
    const a = ev.target.closest('a');
    if(!a) return;
    const href = a.getAttribute('href');
    // ignore external links, anchors, mailto, and links with target
    if(!href || href.startsWith('http') || href.startsWith('mailto:') || href.startsWith('#') || a.target) return;
    // allow ctrl/cmd+click to open in new tab
    if(ev.metaKey || ev.ctrlKey || ev.shiftKey || ev.altKey) return;
    ev.preventDefault();
    playExitAndThen(function(){ window.location = href; });
  }, {capture:false});

  // intercept form submits (to animate then submit)
  document.addEventListener('submit', function(ev){
    const form = ev.target;
    // allow forms with attribute data-no-transition to skip
    if(form.hasAttribute('data-no-transition')) return;
    ev.preventDefault();
    // gather action and method to perform programmatic submit after animation
    const action = form.getAttribute('action') || window.location.pathname;
    const method = (form.getAttribute('method') || 'get').toLowerCase();
    // create and submit via fetch for POST to avoid double navigation; fallback to normal submit
    playExitAndThen(function(){
      // if method is get, navigate with serialized params
      if(method === 'get'){
        const params = new URLSearchParams(new FormData(form)).toString();
        window.location = action + (params ? ('?' + params) : '');
      } else {
        // create a real form and submit (preserves enctype, files etc.)
        const tmp = document.createElement('form');
        tmp.style.display = 'none';
        tmp.method = method;
        tmp.action = action;
        // copy inputs
        new FormData(form).forEach(function(value, key){
          const inp = document.createElement('input'); inp.type = 'hidden'; inp.name = key; inp.value = value; tmp.appendChild(inp);
        });
        document.body.appendChild(tmp);
        tmp.submit();
      }
    });
  }, true);

  // check if background image exists; if not, enable CSS fallback blobs
  (function(){
    const img = new Image();
    img.src = '/static/images/bg-blobs.png';
    img.onload = function(){ /* image ok - nothing to do */ };
    img.onerror = function(){ document.body.setAttribute('data-bg','fallback'); };
  })();
});
